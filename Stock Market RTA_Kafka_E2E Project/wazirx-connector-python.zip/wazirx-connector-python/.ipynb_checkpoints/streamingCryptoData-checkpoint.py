## This program triggers the WazirX API to get the real-time Crypto data. WazirX is an Indian cryptocurrency exchange.
## usage: python/python3 streamingCryptoData.py


# Importing necessary libraries
import pandas as pd
import numpy as np
import asyncio, websockets, requests
import os, sys, random, json
from wazirx_sapi_client.rest import Client
from wazirx_sapi_client.websocket import WebsocketClient

from tqdm import tqdm
from configparser import ConfigParser
from datetime import datetime

import warnings
warnings.filterwarnings("ignore")



# Reading Config File for fetching the Wazirx API keys
cfg_file = 'Config.ini'
config = ConfigParser(interpolation=None)
config.read(cfg_file, encoding ='utf-8')
# Storing the contents of the config file into respective dictinary variables
wazirx_keys = dict(config.items('wazirx-keys'))


# Extract tickers data and convert it into a dataframe

def extractTickers(conn):
    tickers = conn.send('tickers')[1]
    df = pd.DataFrame(tickers)
    df['openPrice'] = df['openPrice'].astype(float)
    df['lowPrice']  = df['lowPrice'].astype(float)
    df['highPrice'] = df['highPrice'].astype(float)
    df['lastPrice'] = df['lastPrice'].astype(float)
    df['volume']    = df['volume'].astype(float)
    df['bidPrice']  = df['bidPrice'].astype(float)
    df['askPrice']  = df['askPrice'].astype(float)
    df['datetime']  = pd.to_datetime(df['at'], unit='ms')
    
    return df


if __name__ == "__main__":
    
    # Testing the API connection
    client = Client(api_key=wazirx_keys['api_key'], secret_key=wazirx_keys['secret_key'])
    print('Pinging WazirX Server: ',client.send("ping"))
    
    #oop = asyncio.get_event_loop()
    loop.create_task(extractTickers(client))
    if len(extractTickers(client) > 2000):
        loop.stop()
    else:
        loop.run_forever()

